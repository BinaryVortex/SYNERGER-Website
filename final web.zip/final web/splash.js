// Wait for the DOM content to be fully loaded
document.addEventListener("DOMContentLoaded", function() {
    // Get the splash screen element
    const splashScreen = document.querySelector('.splash');

    // Fade out the splash screen after 3 seconds
    setTimeout(function() {
        splashScreen.style.opacity = '0';
        // Hide the splash screen completely after fading out
        setTimeout(function() {
            splashScreen.style.display = 'none';
        }, 500); // 500ms delay to match the CSS transition duration
    }, 3000);
});
